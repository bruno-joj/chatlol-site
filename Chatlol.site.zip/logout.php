<?php
require_once 'config.php';

logout();
header('Location: login.php');
exit;
?>